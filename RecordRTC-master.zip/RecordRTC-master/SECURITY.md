## Reporting a Vulnerability
Please report any secuirty vulnerability via Github Security Advisory, by drafting it [here privately](https://github.com/muaz-khan/RecordRTC/security).
